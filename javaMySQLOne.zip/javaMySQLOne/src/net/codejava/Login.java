package net.codejava;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frame;
	private JTextField user;
	private JTextField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 561, 478);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setBounds(0, 0, 545, 439);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.MAGENTA);
		panel_1.setBounds(118, 11, 417, 417);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		user = new JTextField();
		user.setBounds(223, 115, 164, 20);
		panel_1.add(user);
		user.setColumns(10);
		
		passwordField = new JTextField();
		passwordField.setBounds(223, 168, 164, 20);
		panel_1.add(passwordField);
		passwordField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("USER NAME : ");
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 14));
		lblNewLabel.setBounds(69, 116, 114, 19);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD : ");
		lblNewLabel_1.setFont(new Font("Verdana", Font.BOLD, 14));
		lblNewLabel_1.setBounds(69, 164, 114, 25);
		panel_1.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("LOGIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String un = user.getText();
				String pas=passwordField.getText();
				
				if(un.equals("admin")&&pas.equals("123"))
				{
					//JOptionPane.showMessageDialog(null, "Login Successful");
					frame.dispose();
					Menu m=new Menu();
					m.setVisible(true);		
				}		
				else if(un.equals("admin"))
				{
					JOptionPane.showMessageDialog(null, "Invalid Password");
					passwordField.setText("");
					user.requestFocus();
				}
				else if(pas.equals("123"))
				{
					JOptionPane.showMessageDialog(null, "Invalid username");
					user.setText("");
					user.requestFocus();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Enter valid username and password");
					user.setText("");
					passwordField.setText("");
					user.requestFocus();
				}
			}
		});
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 12));
		btnNewButton.setBounds(124, 268, 89, 23);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("CANCEL");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Verdana", Font.BOLD, 12));
		btnNewButton_1.setBounds(255, 268, 89, 23);
		panel_1.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("LOGIN PAGE");
		lblNewLabel_2.setForeground(new Color(128, 0, 0));
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 23));
		lblNewLabel_2.setBounds(140, 29, 154, 43);
		panel_1.add(lblNewLabel_2);
	}
}
