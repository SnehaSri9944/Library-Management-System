package net.codejava;

import java.sql.Connection;
import java.util.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class MySQLTest {
	Connection connection = null;
	public static Connection db() {
		String url = "jdbc:mysql://localhost:3306/trial";
		String username = "root";
		String password = "root";
		Scanner sc = new Scanner(System.in);
		try {
			Connection connection = DriverManager.getConnection(url, username, password);
			
			
					int m;
					do {
						System.out.println("Enter 1 to add user");
						System.out.println("Enter 2 to delete user");
						System.out.println("Enter 3 to search user account");
						System.out.println("Enter 4 to view all account");
						System.out.println("Enter 5 to exit");
						System.out.println("Enter ur choice");
						m=sc.nextInt();
						switch(m)
						{
							case 1:
								String sql1 = "INSERT INTO details (s_id, s_name, s_email, phone_number, department, batch) VALUES (?, ?, ?, ?, ?, ?)";
								PreparedStatement statement1 = connection.prepareStatement(sql1);
								
								System.out.println("Enter Student id");
								int n=sc.nextInt();
								System.out.println("Enter Student name");
								sc.nextLine();
								String sname=sc.nextLine();
								System.out.println("Enter Student mail address");
								String smail=sc.next();
								System.out.println("Enter Student phone number");
								String phno=sc.next();
								System.out.println("Enter department");
								String dep=sc.next();
								System.out.println("Enter batch");
								String sbatch=sc.next();
								statement1.setInt(1, n);
								statement1.setString(2, sname);
								statement1.setString(3, smail);
								statement1.setString(4, phno);
								statement1.setString(5, dep);	
								statement1.setString(6, sbatch);
								System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

								int rows = statement1.executeUpdate();
								if(rows > 0)
								{
									System.out.println("1 row is inserted...!");
								}
								System.out.println("___________________________________________________________________________________________________________________________________________");
								statement1.close();
								break;
							case 2: 
								String sql2 = "DELETE FROM details WHERE (s_id = ?)";
								PreparedStatement statement2 = connection.prepareStatement(sql2);
								System.out.println("Enter the id of the student to be DELETED from list");
								statement2.setInt(1, sc.nextInt());
//								statement2.setString(2, sc.next());
								System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------");
			
								int row = statement2.executeUpdate();
								if(row > 0)
								{
									System.out.println("1 row is deleted...!");
								}
								else
									System.out.println("Sorry....! the row is empty!");
								System.out.println("_______________________________________________________________________________________________________________________________________________");
								statement2.close();
								break;
							case 3:
								
								 System.out.println("Enter the Student id to view profile");
								 int a =sc.nextInt();
								 String sql3 = "SELECT * FROM DETAILS WHERE s_id='"+a+"'";
								 Statement statement3 = connection.createStatement();

					             ResultSet rs = statement3.executeQuery(sql3);
					             if(rs.next()==false) {
					            	 System.out.println("Sorry...There is no books available in the field");
					             }
					             else {
						             try {
						            	 do
						            	 {
						            	 	int b_id = rs.getInt("s_id");
											String b_name = rs.getString("s_name");
											String b_email = rs.getString("s_email");
											String mobile = rs.getString("phone_number");
											String dept = rs.getString("department");
											String b_batch = rs.getString("batch");
											System.out.println("Student id: "+b_id + "\nStudent name: " + b_name + "\nStudent email: " + b_email + "\nPhone number: " + mobile + "\ndepartment: " + dept + "\nBatch: " + b_batch);
											System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						            	 }while(rs.next());
						             }catch(SQLException e1)
						             {
						            	 System.out.println("sorry");
						             }
					             }
								 System.out.println("___________________________________________________________________________________________________________________________________________________________________________");
					             break;
							case 4:
								String sql4 = "SELECT * FROM details";
								Statement statement4 = connection.createStatement();
								ResultSet result = statement4.executeQuery(sql4);
								
								int count=0;
								
								while(result.next())
								{
									int s_id = result.getInt("s_id");
									String s_name = result.getString("s_name");
									String s_email = result.getString("s_email");
									String phone_number = result.getString("phone_number");
									String department = result.getString("department");
									String batch  = result.getString("batch");
									
									count++;
									System.out.println("Student id: " +s_id + "\nStudent name: " + s_name + "\nStudent email: " + s_email + "\nPhone number: " + phone_number + "\ndepartment: " + department + "\nBatch: " + batch);
									System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");
								}
								System.out.println("______________________________________________________________________________________________________________________________________________________________________________________");
								break;
							case 5:
								System.out.println("U have chosen to exit...");
								System.out.println("exited from the user page  :) ");
								System.out.println("______________________________________________________________________________________________________________________________________________________________________________________");

								break;
							default:
								System.out.println("Enter choice from 1 - 5....!");
						}
					}while(m!=5);	
			
			connection.close();
			return connection;
			//System.out.println("yaaahooo....connected to db...!");
		} catch (SQLException e) {
			System.out.println("error....! PLEASE CHECK UR DATA");
			//e.printStackTrace();
			return null;
		}
	}

}
