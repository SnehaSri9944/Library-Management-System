package net.codejava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class MySQLTestIssuedBook {
	Connection connection = null;
	public static Connection data()
	{
		String url = "jdbc:mysql://localhost:3306/trial";
		String username = "root";
		String password = "root";
		Scanner sc = new Scanner(System.in);
		
		try {
			Connection connection = DriverManager.getConnection(url, username, password);
			
			int c;
			System.out.println("Enter 1 to search---calculate fine---reset return date of book \nEnter 2 to add---delete---view book");
			c=sc.nextInt();
			if(c==1) {
				int m;
				do {
					System.out.println("Enter 1 to add book");
					System.out.println("Enter 2 to delete book");
					System.out.println("Enter 3 to view issued list");
					System.out.println("Enter 4 to calculate fine");
					System.out.println("Enter 5 to set return date");
					System.out.println("Enter 6 to exit");
					System.out.println("Enter ur choice");
					m=sc.nextInt();
					switch(m)
					{
						case 1:
							String sql1 = "INSERT INTO ISSUED (i_id, i_date, s_id, b_id) VALUES (?, ?, ?, ?)";
							PreparedStatement statement1 = connection.prepareStatement(sql1);
							System.out.println("Enter Book Issue ID");
							statement1.setInt(1, sc.nextInt());
							System.out.println("Enter Book Issued Date");
							String str=sc.next();
							SimpleDateFormat df = new SimpleDateFormat("yyyy-mm-dd");
							try {
								java.util.Date myDate = df.parse(str);
							} catch (ParseException e) {
								System.out.println("no");
							}
							
							java.sql.Date sqlDate = java.sql.Date.valueOf(str);
							//Date date=new Date();
							
							statement1.setDate(2, sqlDate);
							System.out.println("Enter Student ID");
							statement1.setInt(3, sc.nextInt());
							System.out.println("Enter Book ID");
							statement1.setInt(4, sc.nextInt());
							System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");

							int rows = statement1.executeUpdate();
							if(rows > 0)
							{
								System.out.println("1 row is inserted...!");
							}
							System.out.println("___________________________________________________________________________________________________________________________________________________________________________");

							statement1.close();
							break;
						case 2: 
							String sql2 = "DELETE FROM ISSUED WHERE (i_id = ?)";
							PreparedStatement statement2 = connection.prepareStatement(sql2);
							System.out.println("Enter Book Issue ID");
							statement2.setString(1, sc.next());
//							statement2.setString(2, sc.next());
							System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");

							int row = statement2.executeUpdate();
							if(row > 0)
							{
								System.out.println("1 row is deleted...!");
							}
							else
								System.out.println("Sorry....! the row is empty!");
							System.out.println("___________________________________________________________________________________________________________________________________________________________________________");

							statement2.close();
							break;
						case 3:
							String sql3 = "SELECT * FROM issued";
							Statement statement3 = connection.createStatement();
							ResultSet result = statement3.executeQuery(sql3);
							
							int count=0;
							
							while(result.next())
							{
								int r_id = result.getInt("i_id");
								Date r_name = result.getDate("i_date");
								Date r_date = result.getDate("r_date");
								int r_period = result.getInt("period");
								int r_fine = result.getInt("fine");
								int s_id = result.getInt("s_id");
								int b_id = result.getInt("b_id");
								
								count++;
								System.out.println("Book Isuue ID: " +r_id + "\nBook Issue Date: " + r_name + "\nBook Returned Date: " + r_date + "\nPeriod of Time Taken: " + r_period + "\nFine Amount: " + r_fine + "\nStudent ID: "+ s_id + "\nBook ID: " +b_id);
								System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");

							}
							System.out.println("___________________________________________________________________________________________________________________________________________________________________________");

							break;
							
						case 4:
							 System.out.println("Enter Book Issued ID");
							 int i=sc.nextInt();
							 System.out.println("Enter the current date");
							 String da = sc.next();
							 String sql4="SELECT DATEDIFF(CURDATE(),I_DATE) FROM ISSUED";
							 Statement stmt4 = connection.createStatement();
							 //String da=sc.next();
							 ResultSet rs10 = stmt4.executeQuery(sql4);
							 int fine=1;
							 do
							 {
								 try {
		                                String period = rs10.getString("DATEDIFF(CURDATE(),I_DATE)");
		                                if(fine==i) {
		                                	int k=Integer.parseInt(period)-15;
		                                	if(k>0)
		                                	{
			                                	System.out.println("The fine amount of is :" + k);
			                                	stmt4.executeUpdate("UPDATE ISSUED SET FINE='"+ k +"' WHERE I_ID='"+ i +"'");
		                                	}
		                                	else
		                                	{
		                                		System.out.println("No fine amount....!");
			                                	stmt4.executeUpdate("UPDATE ISSUED SET FINE='0' WHERE I_ID='"+ i +"'");

		                                	}
		                                	stmt4.executeUpdate("UPDATE ISSUED SET PERIOD='"+ period +"' WHERE I_ID='"+ i +"'");
		                                	stmt4.executeUpdate("UPDATE trial.issued SET r_date = '"+ da + "' WHERE (`i_id` = '" + i + "')");
		        							System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		                                	break;
		                                }
		                                else {
		                                	//System.out.println("fine before "+fine);
		                                	fine++;
		                                	//System.out.println("fine after "+fine);
		                                }
		                                 
		                            } catch (SQLException e1) {
		                                //System.out.println(e1);
		                            }
							 }while(rs10.next());
							 System.out.println("___________________________________________________________________________________________________________________________________________________________________________");

				             break;
						case 5:
							System.out.println("Enter Book Issued ID");
							int h=sc.nextInt();
							System.out.println("Enter Return Date");
							
							String date1=sc.next();
							
							String sql5=("UPDATE trial.issued SET r_date = '"+ date1 + "' WHERE (`i_id` = '" + h + "')");
							Statement stmt5 = connection.createStatement();
							
							stmt5.executeUpdate(sql5);
							System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");
							
							System.out.println("UPDATED SUCCESSFULLY...!");
							System.out.println("___________________________________________________________________________________________________________________________________________________________________________");
							break;
							
						case 6:
							System.out.println("U have chosen to exit...");
							System.out.println("exited from the user page  :)  ");
							break;
						default:
							System.out.println("Enter choice from 1 - 6....!");
					}
				}while(m!=6);
			}
			else if(c==2) {
				String n;
				do {
					System.out.println("Enter A to view issued books using ISSUED id");
					System.out.println("Enter B to view issued books using STUDENT id");
					System.out.println("Enter C to view issued books using BOOK id");
					System.out.println("Enter D to view issued books using DATE");
					System.out.println("Enter E to exit");
					System.out.println("Enter ur choice");
					n=sc.next();
					switch(n.toUpperCase())
					{
							case "A":
								 System.out.println("Enter Book Issued ID");
								 int a1 =sc.nextInt();
								 String sql4 = "SELECT * FROM issued WHERE i_id='"+a1+"'";
								 Statement stmt1 = connection.createStatement();

					             ResultSet rs1 = stmt1.executeQuery(sql4);
					             if(rs1.next() == false)
								 {
					            	 System.out.println("Sorry...There is no books available in the field");
								 }
					             else
					             {
						             try {
						            	 int cot1=0;
						            	 do
						            	 {
						            		    int r_id = rs1.getInt("i_id");
												Date r_idate = rs1.getDate("i_date");
												Date r_date = rs1.getDate("r_date");
												int r_period = rs1.getInt("period");
												int r_fine = rs1.getInt("fine");
												int s_id = rs1.getInt("s_id");
												int b_id = rs1.getInt("b_id");
												
												cot1++;
												System.out.println("Book Isuue ID: " +r_id + "\nBook Issue Date: " + r_idate + "\nBook Returned Date: " + r_date + "\nPeriod of Time Taken: " + r_period + "\nFine Amount: " + r_fine + "\nStudent ID: "+ s_id + "\nBook ID: " +b_id);
												System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");

										}while(rs1.next());
						             }catch(SQLException e1)
						             {
						            	 System.out.println("sorry...!it does not exist...!try again:)");
						             }
					             }
								 System.out.println("___________________________________________________________________________________________________________________________________________________________________________");

					             break;
							case "B":
								 System.out.println("Enter Student ID");
								 int a2 =sc.nextInt();
								 String sql5 = "SELECT * FROM issued WHERE s_id='"+a2+"'";
								 Statement stmt2 = connection.createStatement();

					             ResultSet rs2 = stmt2.executeQuery(sql5);
					             if(rs2.next() == false)
								 {
					            	 System.out.println("Sorry...There is no books available in the field");
								 }
					             else
					             {
						             try {
						            	 int cot2=0;
						            	 do
						            	 {
						            		    int r_id = rs2.getInt("i_id");
												Date r_idate = rs2.getDate("i_date");
												Date r_date = rs2.getDate("r_date");
												int r_period = rs2.getInt("period");
												int r_fine = rs2.getInt("fine");
												int s_id = rs2.getInt("s_id");
												int b_id = rs2.getInt("b_id");
												
												cot2++;
												System.out.println("Book Isuue ID: " +r_id + "\nBook Issue Date: " + r_idate + "\nBook Returned Date: " + r_date + "\nPeriod of Time Taken: " + r_period + "\nFine Amount: " + r_fine + "\nStudent ID: "+ s_id + "\nBook ID: " +b_id);
												System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");

										}while(rs2.next());
						             }catch(SQLException e1)
						             {
						            	 System.out.println("sorry...!it does not exist...!try again:)");
						             }
					             }
								 System.out.println("______________________________________________________________________________________________________________________________________________________________________________________");

					             break;
							case "C":
								 System.out.println("Enter Book ID");
								 int a3 =sc.nextInt();
								 String sql6 = "SELECT * FROM issued WHERE b_id='"+a3+"'";
								 Statement stmt3 = connection.createStatement();

					             ResultSet rs3 = stmt3.executeQuery(sql6);
					             if(rs3.next() == false)
								 {
					            	 System.out.println("Sorry...There is no books available in the field");
								 }
					             else
					             {
						             try {
						            	 int cot3=0;
						            	 do
						            	 {
						            		    int r_id = rs3.getInt("i_id");
												Date r_idate = rs3.getDate("i_date");
												Date r_date = rs3.getDate("r_date");
												int r_period = rs3.getInt("period");
												int r_fine = rs3.getInt("fine");
												int s_id = rs3.getInt("s_id");
												int b_id = rs3.getInt("b_id");
												
												cot3++;
												System.out.println("Book Isuue ID: " +r_id + "\nBook Issue Date: " + r_idate + "\nBook Returned Date: " + r_date + "\nPeriod of Time Taken: " + r_period + "\nFine Amount: " + r_fine + "\nStudent ID: "+ s_id + "\nBook ID: " +b_id);
												System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");

										}while(rs3.next());
						             }catch(SQLException e1)
						             {
						            	 System.out.println("sorry...!it does not exist...!try again:)");
						             }
					             }
								 System.out.println("______________________________________________________________________________________________________________________________________________________________________________________");

					             break;
							case "D":
								 System.out.println("Enter Book Issue Date");
								 String a4 =sc.next();
								 String sql7 = "SELECT * FROM issued WHERE i_date='"+a4+"'";
								 Statement stmt4 = connection.createStatement();

					             ResultSet rs4 = stmt4.executeQuery(sql7);
					             if(rs4.next() == false)
								 {
					            	 System.out.println("Sorry...There is no books available in the field");
								 }
					             else
					             {
						             try {
						            	 int cot4=0;
						            	 do
						            	 {
						            		    int r_id = rs4.getInt("i_id");
												Date r_idate = rs4.getDate("i_date");
												Date r_date = rs4.getDate("r_date");
												int r_period = rs4.getInt("period");
												int r_fine = rs4.getInt("fine");
												int s_id = rs4.getInt("s_id");
												int b_id = rs4.getInt("b_id");
												
												cot4++;
												System.out.println("Book Isuue ID: " +r_id + "\nBook Issue Date: " + r_idate + "\nBook Returned Date: " + r_date + "\nPeriod of Time Taken: " + r_period + "\nFine Amount: " + r_fine + "\nStudent ID: "+ s_id + "\nBook ID: " +b_id);
												System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------");

										}while(rs4.next());
						             }catch(SQLException e1)
						             {
						            	 System.out.println("sorry...!it does not exist...!try again:)");
						             }
					             }
								System.out.println("______________________________________________________________________________________________________________________________________________________________________________________");

					             break;
							case "E":
								System.out.println("U have chosen to exit...");
								System.out.println("exited from the user page  :)  ");
								System.out.println("______________________________________________________________________________________________________________________________________________________________________________________");

								break;
					}
				}while(n!="E");
			}
			else
				System.out.println("Enter valid choice....!");
				System.out.println("______________________________________________________________________________________________________________________________________________________________________________________");

					
			//System.out.println("yaaahooo....connected to db...!");
			connection.close();
			return connection;
		}catch(SQLException e)
		{
			System.out.println("error....! PLEASE CHECK UR DATA");
			//e.printStackTrace();
			return null;
		}
}
}